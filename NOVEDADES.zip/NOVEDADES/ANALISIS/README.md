# CENTRO DE PRODUCCION DE SOLUCIONES INTELIGENTES -NOVEDADES -
<link href="http://siomi.datasena.com/analitica/Estilo.css" rel="stylesheet" type="text/css" />

<img src="https://blogger.googleusercontent.com/img/a/AVvXsEimdqxynaYJeDRuTUp3lzEWFnnQSC2KTVSxvnV70I2eZ5tOCfjwdNnExSTSm2tCf1xBFHVHwsN80OCpDCO0J80UTNWxPC86s7s5aB8rnizg7guNowqTxhr5Fd9WH48n7pn8uLZNFTgXuSGUH6BNncmfQEpOz9pAe_T0zD8n2-aGZk8-C_l6GWk-aq60fQ=s960">
<br>
<ul>

<li><a href="https://github.com/fegasu/CPSI/tree/main/NOVEDADES#readme">REGRESAR</a></li>